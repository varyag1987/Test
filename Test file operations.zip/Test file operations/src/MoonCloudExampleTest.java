package ru.sfera.demo;


import java.io.IOException;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Map;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.RemoteWebDriver;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

@Disabled
public class MoonCloudExampleTest {

    Logger log = LoggerFactory.getLogger("MoonCloudExampleTest");

    private RemoteWebDriver driver;

    @BeforeEach
    void setUp() throws Exception {
        ChromeOptions capabilities = new ChromeOptions();
        capabilities.setCapability("browserVersion", "92.0");
        capabilities.setCapability("moon5:options", Map.of(
                "enableVideo", true,
                "enableVNC", true,
                "name", "MyCoolTest",
                "screenResolution", "1024x768",
                "sessionTimeout", "3m"
        ));
        //driver = new RemoteWebDriver(new URL("http://localhost:54746/wd/hub"), capabilities);
        //driver = new RemoteWebDriver(new URL("https://username:password@my-company.cloud.aerokube.com/wd/hub"), capabilities);
        driver = new RemoteWebDriver(new URL("https://testing:testing@ppch.sfera.org/wd/hub"), capabilities);
    }

    @AfterEach
    void tearDown() {
        if (driver != null) {
            driver.quit();
            driver = null;
        }
    }

    @Test
    void testTakeScreenshot() throws IOException {
        driver.get("https://demo-maven.sfera.org");

        String pageContent = driver.getPageSource();
        log.info("Page content: " + pageContent);

        Path screenshot = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE).toPath();
        Files.copy(screenshot, Paths.get(driver.getSessionId() + ".png"));
        log.info("Copied screenshot to " + Paths.get(driver.getSessionId() + ".png").toAbsolutePath());

        try {
            Thread.sleep(30000);
        } catch (InterruptedException e) {
            throw new RuntimeException(e);
        }

    }

}